package dataPostTable;

/* This class just bundles together all the pre-validated String values that a 
 * user might enter as part of a Web_User record. 
 */
public class PostTableTyped {
    public String userID="";
    public String prodID="";
    public String post="";
    public java.sql.Date date=null;

    public String buildDisplay(String newLineString) {
        return newLineString
                + "WebUser record" + newLineString
                + "==============" + newLineString
                + "userID: " + myString(this.userID) + newLineString
                + "prodID: " + myString(this.prodID) + newLineString
                + "date: " + myString(this.date) + newLineString
                + "post: " + myString(this.post) + newLineString;
    }

    public String displayHTML() {
        return buildDisplay("<br>");
    }

    public String displayLog() {
        return buildDisplay("\n");
    }

    private String myString(Object obj) {
        if (obj == null) {
            return "null";
        } else {
            return obj.toString();
        }
   }
}
