package dataPostTable;

import utils.*;
import java.sql.*;

/* This class validates a WebUser object (bundle of user entered string values).
 * This class provides one error message per field in a WebUser object.
 * This class demonstrates the use of "object composition" and
 * "Single Responsibility" design principles.
 */
public class PostTableValidate {

    // validation error messages
    private String userIDMsg = "";
    private String prodIDMsg = "";
    private String postMsg = "";
    private String dateMsg = "";
    private boolean isAllGood;
    private String debugMsg = "";
    // Web User data fields from form (all String, pre-validation), bundled
    private PostTable wu;
    // Web User data fields after validation (various data types, post-validation), bundled
    private PostTableTyped wut = new PostTableTyped();
    private String insertError = "";

    public PostTableValidate() {
    }

    public PostTableValidate(PostTable wu) {
        // validationUtils method validates each user input (String even if destined for other type) from WebUser object
        // side effect of validationUtils method puts validated, converted typed value into WebUserTyped object
        this.wu = wu;

        ValidateString vstr = new ValidateString(wu.userID, 45, true);
        wut.userID = vstr.getConvertedString();
        this.userIDMsg = vstr.getError();

        vstr = new ValidateString(wu.prodID, 45, true);
        wut.prodID = vstr.getConvertedString();
        this.prodIDMsg = vstr.getError();

        vstr = new ValidateString(wu.post, 45, true);
        wut.post = vstr.getConvertedString();
        this.postMsg = vstr.getError();

        ValidateDate vdate = new ValidateDate(wu.date, false);
        wut.date = vdate.getConvertedDate();
        this.dateMsg = vdate.getError();

        String allMessages = this.userIDMsg + this.prodIDMsg + this.postMsg + this.dateMsg;
        isAllGood = (allMessages.length() == 0);
    }

    public PostTable getPostTable() {
        return this.wu;
    }

    public PostTableTyped getWebPostTable() {
        return this.wut;
    }

    /**
     * @return the userEmailMsg
     */
    public String getuserIDMsg() {
        return userIDMsg;
    }

    /**
     * @return the membershipFeeMsg
     */
    public String getprodIDMsg() {
        return prodIDMsg;
    }

    /**
     * @return the userRoleMsg
     */
    public String getpostMsg() {
        return postMsg;
    }

    /**
     * @return the dateAddedMsg
     */
    public String getdateMsg() {
        return dateMsg;
    }

    /**
     * @return the isAllGood
     */
    public boolean isAllGood() {
        return isAllGood;
    }

    public String getInsertError() {
        return this.insertError;
    }

    /* Return a PreparedStatement filled with validated data, ready to go. 
     * Or (if exception thrown), return null and let them use getInsertError() to find out why. */
    public PreparedStatement insertStatement(DbConn dbc) {
        this.insertError = "";
        String sql = "INSERT INTO post_table (idweb_user, id_product, post_date, post_msg"
                + ") VALUES (?,?,?,?)";
        try {
            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
            this.debugMsg = "";
            this.debugMsg += EncodeForDbUtils.encodeString(pStatement, 1, wut.userID);
            this.debugMsg += EncodeForDbUtils.encodeString(pStatement, 2, wut.prodID);
            this.debugMsg += EncodeForDbUtils.encodeDate(pStatement, 3, wut.date);
            this.debugMsg += EncodeForDbUtils.encodeString(pStatement, 4, wut.post);
            return pStatement;
        } catch (Exception e) {
            this.insertError = "Problem creating the prepared statement in WebUserValidate.encodeForInsert()."
                    + " Error message: " + e.getMessage();
            return null;
        }
    }
}
