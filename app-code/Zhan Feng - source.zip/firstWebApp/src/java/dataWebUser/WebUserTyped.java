package dataWebUser;

/* This class just bundles together all the pre-validated String values that a 
 * user might enter as part of a Web_User record. 
 */
public class WebUserTyped {
    public String userEmail="";
    public String userPw="";
    public String userPw2="";
    public java.math.BigDecimal membershipFee=null;
    public Integer userRole=null;
    public java.sql.Date birthday=null;

    public String buildDisplay(String newLineString) {
        return newLineString
                + "WebUser record" + newLineString
                + "==============" + newLineString
                + "userEmail: " + myString(this.userEmail) + newLineString
                + "userPw: " + myString(this.userPw) + newLineString
                + "userPw2: " + myString(this.userPw2) + newLineString
                + "membershipFee: " + myString(this.membershipFee) + newLineString
                + "userRole: " + myString(this.membershipFee) + newLineString
                + "birthday: " + myString(this.birthday) + newLineString;
    }

    public String displayHTML() {
        return buildDisplay("<br>");
    }

    public String displayLog() {
        return buildDisplay("\n");
    }

    private String myString(Object obj) {
        if (obj == null) {
            return "null";
        } else {
            return obj.toString();
        }
   }
}
