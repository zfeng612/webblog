/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dataWebUser;

import com.mysql.jdbc.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import utils.DbConn;

/**
 *
 * @author BK
 */
public class Login {

    public int getUserRole(String user_Name, String passW) throws SQLException {

        DbConn dbc = new DbConn();
        ResultSet rst = null;
        Statement stmt = null;
        int user_RoleInt = 0;

        //Get User Email and PW from the DB
        stmt = (Statement) dbc.getConn().createStatement();
        rst = stmt.executeQuery("select * from web_user where user_email = '" + user_Name + "' and user_password= '" + passW + "'");

        if (rst.next()) {
            //Get the user role from the DB
            user_RoleInt = rst.getInt(5);
        }

        rst.close();
        stmt.close();

        return user_RoleInt;
    }

    public int getUserID(String user_Name, String passW) throws SQLException {

        DbConn dbc = new DbConn();
        ResultSet rst = null;
        Statement stmt = null;
        int user_IDInt = 0;

        //Get User Email and PW from the DB
        stmt = (Statement) dbc.getConn().createStatement();
        rst = stmt.executeQuery("select * from web_user where user_email = '" + user_Name + "' and user_password= '" + passW + "'");

        if (rst.next()) {
            //Get the user role from the DB
            user_IDInt = rst.getInt(4);
        }

        rst.close();
        stmt.close();
        return user_IDInt;
    }
}