package dataWebUser;

import utils.*;
import java.sql.*;

/* This class validates a WebUser object (bundle of user entered string values).
 * This class provides one error message per field in a WebUser object.
 * This class demonstrates the use of "object composition" and
 * "Single Responsibility" design principles.
 */
public class WebUserValidate {

    // validation error messages
    private String userEmailMsg = "";
    private String userPwMsg = "";
    private String userPw2Msg = "";
    private String membershipFeeMsg = "";
    private String userRoleMsg = "";
    private String birthdayMsg = "";

    private boolean isAllGood;
    private String debugMsg = "";

    // Web User data fields from form (all String, pre-validation), bundled
    private WebUser wu;
    // Web User data fields after validation (various data types, post-validation), bundled
    private WebUserTyped wut = new WebUserTyped();
    
    private String insertError="";

    public WebUserValidate() {
    }

    public WebUserValidate(WebUser wu) {
        // validationUtils method validates each user input (String even if destined for other type) from WebUser object
        // side effect of validationUtils method puts validated, converted typed value into WebUserTyped object
        this.wu = wu;

        ValidateString vstr = new ValidateString(wu.userEmail, 45, true);
        wut.userEmail = vstr.getConvertedString();
        this.userEmailMsg = vstr.getError();

        vstr = new ValidateString(wu.userPw, 45, true);
        wut.userPw = vstr.getConvertedString();
        this.userPwMsg = vstr.getError();

        vstr = new ValidateString(wu.userPw2, 45, true);
        wut.userPw2 = vstr.getConvertedString();
        if (wut.userPw.compareTo(wut.userPw2) != 0) {
            this.userPw2Msg = "Both passwords must match.";
        }

        ValidateDecimal vdec = new ValidateDecimal(wu.membershipFee, false);
        wut.membershipFee = vdec.getConvertedDecimal();
        this.membershipFeeMsg = vdec.getError();

        ValidateInteger vi = new ValidateInteger(wu.userRole, false);
        wut.userRole = vi.getConvertedInteger();
        this.userRoleMsg = vi.getError();

        ValidateDate vdate = new ValidateDate(wu.birthday, false);
        wut.birthday = vdate.getConvertedDate();
        this.birthdayMsg = vdate.getError();

        String allMessages = this.userEmailMsg + this.userPwMsg + this.userPw2Msg + this.membershipFeeMsg + this.userRoleMsg + this.birthdayMsg;
        isAllGood = (allMessages.length() == 0);
    }

    public WebUser getWebUser() {
        return this.wu;
    }

    public WebUserTyped getWebUserTyped() {
        return this.wut;
    }

    /**
     * @return the userEmailMsg
     */
    public String getUserEmailMsg() {
        return userEmailMsg;
    }

    /**
     * @return the userPwMsg
     */
    public String getUserPwMsg() {
        return userPwMsg;
    }

    /**
     * @return the userPw2Msg
     */
    public String getUserPw2Msg() {
        return userPw2Msg;
    }

    /**
     * @return the membershipFeeMsg
     */
    public String getMembershipFeeMsg() {
        return membershipFeeMsg;
    }

    /**
     * @return the userRoleMsg
     */
    public String getUserRoleMsg() {
        return userRoleMsg;
    }

    /**
     * @return the dateAddedMsg
     */
    public String getBirthdayMsg() {
        return birthdayMsg;
    }

    /**
     * @return the isAllGood
     */
    public boolean isAllGood() {
        return isAllGood;
    }

    public String getInsertError() {
        return this.insertError;
    }
        
    /* Return a PreparedStatement filled with validated data, ready to go. 
     * Or (if exception thrown), return null and let them use getInsertError() to find out why. */
    public PreparedStatement insertStatement(DbConn dbc) {
        this.insertError = "";
        String sql = "INSERT INTO web_user (user_email, user_password, membership_fee, user_role, birthday"
                + ") VALUES (?,?,?,?,?)";
        try {
            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
            this.debugMsg = "";
            this.debugMsg += EncodeForDbUtils.encodeString (pStatement, 1, wut.userEmail);
            this.debugMsg += EncodeForDbUtils.encodeString (pStatement, 2, wut.userPw);
            this.debugMsg += EncodeForDbUtils.encodeDecimal(pStatement, 3, wut.membershipFee);
            this.debugMsg += EncodeForDbUtils.encodeInteger(pStatement, 4, wut.userRole);
            this.debugMsg += EncodeForDbUtils.encodeDate   (pStatement, 5, wut.birthday);
            return pStatement;
        } catch (Exception e) {
            this.insertError  = "Problem creating the prepared statement in WebUserValidate.encodeForInsert()."
                    + " Error message: " + e.getMessage();
            return null;
        }
    }
}
