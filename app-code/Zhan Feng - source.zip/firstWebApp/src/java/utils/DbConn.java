package utils;

import java.sql.*;

/**
 * Wrapper class for database connection.  
 * Constructor opens connection.  Close method closes it.
 */
public class DbConn {

    private String errMsg = ""; // will remain "" unless error getting connection
    private String connectionMsg = ""; // log of getting connection
    private Connection conn = null;

    /**
     * Constructor - opens database connection to database
     */
    public DbConn() { // this version figures out where it is running....
        this.connectionMsg = "";
        try {
            this.connectionMsg += "ready to get driver... <br/>";
            String DRIVER = "com.mysql.jdbc.Driver";
            Class.forName(DRIVER).newInstance();
            this.connectionMsg += "got the driver... <br/>";
            try {
                this.connectionMsg += "ready to get the connection <br/>";
                if (this.isTemple()) {
                    // SP11_2308_sallyk is the name of my database/schema on cis-linux2
                    String url = "jdbc:mysql://cis-linux2.temple.edu/SP12_2308_tuc71760";
                    String user = "tuc71760";
                    String db_pw = "fofiephu";
                    this.conn = DriverManager.getConnection(url, user, db_pw);
                    this.connectionMsg += "got the db connection on cis-linux2" + "<br/>";
                } else {
                    // cis2308 is the name of my database/schema on my local PC at home...
                    String url = "jdbc:mysql://localhost/cis2308?user=root&password=5950080";
                    this.conn = DriverManager.getConnection(url);
                    this.connectionMsg += "got the db connection on localhost" + "<br/>";
                }
                this.connectionMsg += "got the connection " + "<br/>";
            } catch (Exception e) { // cant get the connection
                this.connectionMsg += "problem getting connection:" + e.getMessage() + "<br/>";
                this.errMsg = "problem getting connection:" + e.getMessage();
            }
        } catch (Exception e) { // cant get the driver...
            this.connectionMsg += "problem getting driver:" + e.getMessage() + "<br/>";
            this.errMsg = "problem getting driver:" + e.getMessage();
        }
    } // method

    public DbConn(boolean local) {

        this.connectionMsg = "";
        try {
            this.connectionMsg += "ready to get driver... <br/>";
            String DRIVER = "com.mysql.jdbc.Driver";
            Class.forName(DRIVER).newInstance();
            this.connectionMsg += "got the driver... <br/>";
            try {
                if (local) {
                    // cis2308 is the name of my database/schema on my PC at home...
                    String url = "jdbc:mysql://localhost/cis2308?user=root&password=5950080";
                    this.conn = DriverManager.getConnection(url);
                    this.connectionMsg += "got the db connection on localhost" + "<br/>";
                } else {
                    // SP11_2308_sallyk is the name of my database/schema on cis-linux2
                    String url = "jdbc:mysql://cis-linux2.temple.edu/SP12_2308_tuc71760";
                    String user = "tuc71760";
                    String db_pw = "fofiephu";
                    this.conn = DriverManager.getConnection(url, user, db_pw);
                    this.connectionMsg += "got the db connection on cis-linux2" + "<br/>";
                }
            } catch (Exception e) { // cant get the connection
                this.connectionMsg += "problem getting connection:" + e.getMessage() + "<br/>";
                this.errMsg = "problem getting connection:" + e.getMessage();
            }
        } catch (Exception e) { // cant get the driver...
            this.connectionMsg += "problem getting driver:" + e.getMessage() + "<br/>";
            this.errMsg = "problem getting driver:" + e.getMessage();
        }
    } // method

    /**
     * Returns database connection for use in SQL classes.
     * @return database connection.
     */
    public Connection getConn() {
        return this.conn;
    }

    /**
     * Returns error message or "" if there is none.
     * @return String containing error message or "" if there is no error.
     */
    public String getErr() {
        return this.errMsg;
    }

    public String getConnectionMsg() {
        return this.connectionMsg;  // will have messages even if OK.
    }

    /**
     * Close database connection.
     */
    public void close() {
        // be careful - you can get an error trying to
        // close a connection if it is null.
        if (conn != null) {
            try {
                conn.close();
            } // try
            catch (Exception e) {
                errMsg = "Error closing connection in DbConn: "
                        + e.getMessage();
                System.out.println(errMsg);
                //e.printStackTrace();
            } // catch
        } // if
    } // method

    private boolean isTemple() {
        boolean temple = false;
        try {
            String hostName = java.net.InetAddress.getLocalHost().getCanonicalHostName();
            hostName = hostName.toLowerCase();
            if (hostName.endsWith("temple.edu")) {
                temple = true;
                System.out.println("************* Running from Temple, so using cis-linux2 for db connection");
            }
            else {
                 System.out.println("************* Not running from Temple, so using local for db connection");               
            }
        } catch (Exception e) {
            System.out.println("************* Unable to get hostname. " + e.getMessage());
        }
        return temple;
    }
} // class

