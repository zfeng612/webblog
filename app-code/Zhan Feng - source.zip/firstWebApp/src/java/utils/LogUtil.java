package utils;

/* This class lets you write silent messages to a text file .*/

import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class LogUtil {

    private String fileName = "C:\\a\\sk_log.txt";
    private PrintWriter outputStream;
    private String confirmation = "";

    public LogUtil() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String now = dateFormat.format(date);
        addText("LOG FILE CREATED: " + now, false);
    } // method

    public String append(String msg) {
        return addText(msg, true);
    }

    private String addText(String msg, boolean addToExisting) {
        try {
            outputStream = new PrintWriter(new FileOutputStream(this.fileName, addToExisting));
            outputStream.println(msg + "<br/>");
            outputStream.close();
            confirmation += "LogUtil.append(): Message was appended to the end of file " + this.fileName;
        } // try
        catch (FileNotFoundException e) {
            confirmation += "LogUtil.append() error: " + e.getMessage();
        } // catch
        return confirmation;
    } // method

    public String read() {
        Scanner inputStream = null;
        StringBuilder s = new StringBuilder("");
        s.append("Log File Contents <br/> <br/>");
        try {
            inputStream = new Scanner(new File(this.fileName));
            while (inputStream.hasNextLine()) {
                String line = inputStream.nextLine();
                s.append(line);
            }
            inputStream.close();
        } catch (FileNotFoundException e) {
            String str = "Error " + e.getMessage() + ". Cannot open the file " + fileName;
            s.append(str);
        } // catch
        return s.toString();
    } // method
}
