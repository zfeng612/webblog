package dataProductTable;

import dataProductTable.*;
import utils.*;
import java.sql.*;

/* This class validates a WebUser object (bundle of user entered string values).
 * This class provides one error message per field in a WebUser object.
 * This class demonstrates the use of "object composition" and
 * "Single Responsibility" design principles.
 */
public class ProductTableValidate {

    // validation error messages
    private String productNameMsg = "";
    private String productPriceMsg = "";
    private String productTypeMsg = "";
    private String productDateMsg = "";
    private boolean isAllGood;
    private String debugMsg = "";
    // Web User data fields from form (all String, pre-validation), bundled
    private ProductTable wu;
    // Web User data fields after validation (various data types, post-validation), bundled
    private ProductTableTyped wut = new ProductTableTyped();
    private String insertError = "";

    public ProductTableValidate() {
    }

    public ProductTableValidate(ProductTable wu) {
        // validationUtils method validates each user input (String even if destined for other type) from WebUser object
        // side effect of validationUtils method puts validated, converted typed value into WebUserTyped object
        this.wu = wu;

        ValidateString vstr = new ValidateString(wu.productName, 45, true);
        wut.productName = vstr.getConvertedString();
        this.productNameMsg = vstr.getError();

        vstr = new ValidateString(wu.productType, 45, true);
        wut.productType = vstr.getConvertedString();
        this.productTypeMsg = vstr.getError();

        ValidateDecimal vdec = new ValidateDecimal(wu.productPrice, false);
        wut.productPrice = vdec.getConvertedDecimal();
        this.productPriceMsg = vdec.getError();

        ValidateDate vdate = new ValidateDate(wu.productDate, false);
        wut.productDate = vdate.getConvertedDate();
        this.productDateMsg = vdate.getError();

        String allMessages = this.productNameMsg + this.productTypeMsg + this.productPriceMsg + this.productDateMsg;
        isAllGood = (allMessages.length() == 0);
    }

    public ProductTable getProductTable() {
        return this.wu;
    }

    public ProductTableTyped getWebProductTable() {
        return this.wut;
    }

    /**
     * @return the userEmailMsg
     */
    public String getProductNameMsg() {
        return productNameMsg;
    }

    /**
     * @return the membershipFeeMsg
     */
    public String getProductPriceMsg() {
        return productPriceMsg;
    }

    /**
     * @return the userRoleMsg
     */
    public String getProductTypeMsg() {
        return productTypeMsg;
    }

    /**
     * @return the dateAddedMsg
     */
    public String getProductDateMsg() {
        return productDateMsg;
    }

    /**
     * @return the isAllGood
     */
    public boolean isAllGood() {
        return isAllGood;
    }

    public String getInsertError() {
        return this.insertError;
    }

    /* Return a PreparedStatement filled with validated data, ready to go. 
     * Or (if exception thrown), return null and let them use getInsertError() to find out why. */
    public PreparedStatement insertStatement(DbConn dbc) {
        this.insertError = "";
        String sql = "INSERT INTO product_table (product_name, price, product_type, release_date"
                + ") VALUES (?,?,?,?)";
        try {
            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
            this.debugMsg = "";
            this.debugMsg += EncodeForDbUtils.encodeString(pStatement, 1, wut.productName);
            this.debugMsg += EncodeForDbUtils.encodeDecimal(pStatement, 2, wut.productPrice);
            this.debugMsg += EncodeForDbUtils.encodeString(pStatement, 3, wut.productType);
            this.debugMsg += EncodeForDbUtils.encodeDate(pStatement, 4, wut.productDate);
            return pStatement;
        } catch (Exception e) {
            this.insertError = "Problem creating the prepared statement in WebUserValidate.encodeForInsert()."
                    + " Error message: " + e.getMessage();
            return null;
        }
    }
}
