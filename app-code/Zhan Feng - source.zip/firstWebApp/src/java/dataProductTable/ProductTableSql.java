package dataProductTable;

import dataProductTable.*;
import utils.DbConn;
import java.sql.*;
import utils.*;

/**
 * This class contains all code that modifies or lists the Web_user table in the
 * database. So, Insert, Update, Delete, and select code will be in this class
 * (eventually). This class requires an open database connection for its
 * constructor method.
 */
public class ProductTableSql {

    private DbConn dbc;  // Open, live database connection
    private String errorMsg = "";
    private String debugMsg = "";

    // all methods of this class require an open database connection.
    public ProductTableSql(DbConn dbc) {
        this.dbc = dbc;
    }

    public String getDebugMsg() {
        return this.debugMsg;
    }

    public String getErrorMsg() {
        return this.errorMsg;
    }

    public boolean delete(String primaryKey) {
        this.errorMsg = "";  // clear any error message from before.
        String sql = "DELETE FROM product_table where id_product=?";
        try {
            PreparedStatement sqlSt = this.dbc.getConn().prepareStatement(sql);
            sqlSt.setString(1, primaryKey);

            int numRows = sqlSt.executeUpdate();
            if (numRows == 1) {
                this.errorMsg = "";
                return true; // all is GOOD
            } else {
                this.errorMsg = new Integer(numRows).toString()
                        + " records were deleted."; // probably never get here
                return false;
            }
        } // try
        catch (SQLException e) {
            this.errorMsg = "";
            if (e.getSQLState().equalsIgnoreCase("S1000")) {
                this.errorMsg = "Could not delete.";
            }

            this.errorMsg += "<br/><br/>Problem with SQL in ProductTableSql.delete: "
                    + "SQLState [" + e.getSQLState()
                    + "], error message [" + e.getMessage() + "]";
            System.out.println(this.errorMsg);
            //e.printStackTrace();
            return false;
        } // catch
        catch (Exception e) {
            this.errorMsg = "General Error in ProductTableSql.delete: "
                    + e.getMessage();
            System.out.println(this.errorMsg);
            //e.printStackTrace();
            return false;
        } // catch
    }// method

    /*
     * This method requires a pre-validated Web_User object. It also assumes
     * that an open database connection was provided to the constructor. It
     * returns true if it is able to insert the Web_User object into the
     * database.
     */
    public String insert(ProductTableValidate wuv) {
        this.errorMsg = "";// empty error message means it worked.
        // dont even try to insert if the record didnt pass validation.
        if (!wuv.isAllGood()) {
            return "Please edit record and resubmit";
        }

        //String sql = wuv.getInsertSql();
        //PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
        PreparedStatement pStatement = wuv.insertStatement(dbc);
        if (pStatement == null) {
            return "Problem encoding the INSERT prepared statement: " + wuv.getInsertError();
        }
        System.out.println("************* I got past encoding");
        try {
            int numRows = pStatement.executeUpdate();
            if (numRows == 1) {
                return ""; // all is GOOD, one record inserted is what we expect
            } else {
                this.errorMsg = new Integer(numRows).toString()
                        + " records were inserted."; // probably never get here, bulk sql insert???
                return this.errorMsg;
            }
        } // try execute the statement
        catch (SQLException e) {
            if (e.getSQLState().equalsIgnoreCase("S1000")) {
                this.errorMsg = "Can't add - record with that ID exists (should not happen since web_user has auto-increment primary key).";
            } else {
                this.errorMsg = "Problem with SQL in WebUserSql.insert(): "
                        + "SQLState:" + e.getSQLState()
                        + ", Error message: " + e.getMessage();
                // this message would show up in the NetBeans log window (below the editor)
                System.out.println("*************" + this.errorMsg);
            }
            return this.errorMsg;
        } // catch
        catch (Exception e) {
            // this message would show up in the NetBeans log window (below the editor)
            this.errorMsg = "General Error in WebUserSql.insert(): " + e.getMessage();
            System.out.println("******************" + this.errorMsg);
            return this.errorMsg;
        } // catch
    }// method

    public String listAllUsers(String cssClassForResultSetTable) {
        StringBuilder sb = new StringBuilder("");
        Statement stmt = null;
        ResultSet rst = null;
        try {
            //sb.append("ready to create the statement & execute query " + "<br/>");
            stmt = this.dbc.getConn().createStatement();
            rst = stmt.executeQuery("select id_product, product_name, price, product_type, release_date from product_table");
            //sb.append("executed the query " + "<br/><br/>");
            sb.append("<table class='");
            sb.append(cssClassForResultSetTable);
            sb.append("'>");
            sb.append("<tr>");
            sb.append("<th style='text-align:left'>ID</th>");
            sb.append("<th style='text-align:right'>Name</th>");
            sb.append("<th style='text-align:right'>Price</th>");
            sb.append("<th style='text-align:right'>Type</th>");
            sb.append("<th style='text-align:center'>Release Date</th></tr>");
            while (rst.next()) {
                sb.append("<tr>");
                sb.append(FormatUtils.formatInteger(rst.getObject(1)));
                sb.append(FormatUtils.formatString(rst.getObject(2)));
                sb.append(FormatUtils.formatDollar(rst.getObject(3)));
                sb.append(FormatUtils.formatString(rst.getObject(4)));
                sb.append(FormatUtils.formatDate(rst.getObject(5)));
                sb.append("</tr>\n");
            }
            sb.append("</table>");
            rst.close();
            stmt.close();
            return sb.toString();
        } catch (Exception e) {
            return "Exception thrown in WebUserSql.listAllUsers(): " + e.getMessage()
                    + "<br/> partial output: <br/>" + sb.toString();
        }
    }

    public String listAllUsers(String cssClassForResultSetTable, String delFn, String delIcon, String insFn, String insIcon) {
        if ((delIcon == null) || (delIcon.length() == 0)) {
            return "WebUserSql.listAllUsers() error: delete Icon (String input parameter) is null or empty.";
        }
        if ((delFn == null) || (delFn.length() == 0)) {
            return "WebUserSql.listAllUsers() error: delete javascript function (String input parameter) is null or empty.";
        }

        if ((insIcon == null) || (insIcon.length() == 0)) {
            return "WebUserSql.listAllUsers() error: ins Icon (String input parameter) is null or empty.";
        }
        if ((insFn == null) || (insFn.length() == 0)) {
            return "WebUserSql.listAllUsers() error: ins javascript function (String input parameter) is null or empty.";
        }

        String delStart = "<td style='border:none'><a href='javascript:" + delFn + "("; // up to PK value/input parameter to js fn.
        String delEnd = ")'><img src='" + delIcon + "'></a></td>"; // after PK value/input parameter to js fn.

        String insStart = "<td style='border:none'><a href='javascript:" + insFn + "("; // up to PK value/input parameter to js fn.
        String insEnd = ")'><img src='" + insIcon + "'></a></td>"; // after PK value/input parameter to js fn.

        StringBuilder sb = new StringBuilder("");

        Statement stmt = null;
        ResultSet rst = null;
        try {
            //sb.append("ready to create the statement & execute query " + "<br/>");
            stmt = this.dbc.getConn().createStatement();
            rst = stmt.executeQuery("select id_product, product_name, price, product_type, release_date from product_table");
            //sb.append("executed the query " + "<br/><br/>");
            sb.append("<table class='");
            sb.append(cssClassForResultSetTable);
            sb.append("'>");
            sb.append("<tr>");
            sb.append("<th style='border:none'>&nbsp;</th>");// extra column at left for delete icon
            sb.append("<th style='text-align:right'>ID</th>");
            sb.append("<th style='text-align:left'>Name</th>");
            sb.append("<th style='text-align:left'>Price</th>");
            sb.append("<th style='text-align:left'>Type</th>");
            sb.append("<th style='text-align:center'>Release Date</th></tr>");
            while (rst.next()) {
                Object primaryKeyObj = rst.getObject(1);
                Integer primaryKeyInt = (Integer) primaryKeyObj;
                sb.append("<tr>");

                // this is the column with a delete icon that has a link to a javascript function.
                // the input parameter to the delete javascript function is the PK of the user in this row.
                sb.append(delStart);
                sb.append(primaryKeyInt.toString());
                sb.append(delEnd);

                sb.append(FormatUtils.formatInteger(primaryKeyObj));
                sb.append(FormatUtils.formatString(rst.getObject(2)));
                sb.append(FormatUtils.formatDollar(rst.getObject(3)));
                sb.append(FormatUtils.formatString(rst.getObject(4)));
                sb.append(FormatUtils.formatDate(rst.getObject(5)));

                sb.append(insStart);
                sb.append(primaryKeyInt.toString());
                sb.append(insEnd);

                sb.append("</tr>\n");
            }
            sb.append("</table>");
            rst.close();
            stmt.close();
            return sb.toString();
        } catch (Exception e) {
            return "Exception thrown in WebUserSql.listAllUsers(): " + e.getMessage()
                    + "<br/> partial output: <br/>" + sb.toString();
        }
    }
} // class

