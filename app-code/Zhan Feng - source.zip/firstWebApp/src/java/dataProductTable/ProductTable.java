package dataProductTable;

/* This class just bundles together all the pre-validated String values that a 
 * user might enter as part of a Web_User record. 
 */
public class ProductTable {

    public String productName = "";
    public String productType = "";
    public String productPrice = "";
    public String productDate = "";

    public String buildDisplay(String newLineString) {
        return newLineString
                + "WebUser record" + newLineString
                + "==============" + newLineString
                + "productName: " + myString(this.productName) + newLineString
                + "productType: " + myString(this.productType) + newLineString
                + "productPrice: " + myString(this.productPrice) + newLineString
                + "productDate: " + myString(this.productDate) + newLineString;
    }

    public String displayHTML() {
        return buildDisplay("<br>");
    }

    public String displayLog() {
        return buildDisplay("\n");
    }

    private String myString(Object obj) {
        if (obj == null) {
            return "null";
        } else {
            return obj.toString();
        }
    }
}
